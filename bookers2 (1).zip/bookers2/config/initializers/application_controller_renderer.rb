# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd2339deaa9bb22610f0492c5d154e22541cac1b26ba2fea00ed325af4bb9227c184a70f5194b566bb5c80d3c62dce7ed3407d2fb744eb2aaa2dc7a32217be93d'
Refile.secret_key = '077fd9ee56267802b4b80ebddec68f578fc61182144c1c34ed7168ca5b7d72b079dd035d78e0c15892521ae259628e51e76105cce0ccffb3d01eff5c24a88d66'
Refile.secret_key = 'f039b5087dbbfc659b0293bf52464a6594176d439c747e7f23313a84105f24b1ff36874014741e4b815d3aa6384b3fafc194fe0836e1a4ae488927fead14ada8'
Refile.secret_key = '78e27ebf3fea3a651f45222388f9318d1d6b7d6a8c6b53536bb3378ac9cb8656f856aff266cd2d1c28f18797b44c63e8f244851c72f4f5bfbfd88eb01de2468c'